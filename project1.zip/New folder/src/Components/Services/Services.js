import React from 'react'
import './Services.css'
import {FaCocktail,FaHiking,FaTaxi} from 'react-icons/fa'
import {GiWashingMachine} from 'react-icons/gi'
import {CgGym} from 'react-icons/cg'
import {IoBeerSharp} from 'react-icons/io5'

const Services = () => {
  return (
    <div className=''>
        <div className='s_container  grid justify-center'>
        <h1 className='text-3xl md:text-5xl '>Services</h1>
        <div className='border-b-2 w-2/3  border-sky-700'/>
        </div>
        <div style={{marginTop:"500px"}} className='ml-4  grid grid-cols-2 md:grid-cols-3 text-xl md:text-3xl mt-10'>
        
            <div className=' hover:text-yellow-300 cursor-pointer'>
                <div className='grid justify-center'>
                <div><FaCocktail/></div>
                </div>
                <h4 className='text-center'>Free Cocktails</h4>
            </div>
            <div className=' hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><FaHiking/></div>
                </div>
                <h4 className='text-center'>Tourist Guide</h4>
            </div>
            <div className='mt-12 md:mt-0 hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><FaTaxi/></div>
                </div>
                <h4 className='text-center'>Cab Service</h4>
            </div>
       
            <div className='mt-12 md:mt-20 hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><GiWashingMachine/></div>
                </div>
                <h4 className='text-center'>Free Laundry</h4>
            </div>
            <div className='mt-12 md:mt-20 hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><CgGym/></div>
                </div>
                <h4 className='text-center'>Gym</h4>
            </div>
            <div className='mt-12 md:mt-20 hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><IoBeerSharp/></div>
                </div>
                <h4 className='text-center'>Strongest Beer</h4>
            </div>
        
        </div>
    </div>
  )
}

export default Services