import React, { useState } from 'react'
import logo from './logo.png'
import bg from './bg.jpg'
import "./Navbar.css"
import NavBar2 from './NavBar2'
import Typewriter from "typewriter-effect";

const Navbar1 = () => {

  const [isScrolled, setisScrolled] = useState(false);
    window.onscroll = () => {
        setisScrolled(window.pageYOffset < 50 ? true : false);
        return () => (window.onscroll = null);
      };

  return (
    <>
     <img  className='img_bg h-96 md:h-2/3 xl:h-2/4' src={bg} alt=''/>
     {isScrolled?
      <div className='flex ease-in duration-300'>
        <div className='para ease-in duration-300 fixed bg-white w-36 h-16 md:w-1/3 xl:w-1/4 md:h-24'>
          <div className='lg:flex'>
            <div className='mt-2 md:mt-4 lg:ml-8 lg:my-5 w-7 ml-7 lg:mt-7 md:ml-16 lg:ml-1 xl:ml-10'>
            <img src={logo} alt=""/>
            </div>
            <div className='md:static text-xs md:text-lg lg:text-xl font-semibold lg:mt-7 ml-2'>
            <div>tmn's Roommate</div>
            </div>
          </div>
        </div>
        <div className='fixed p-3  md:p-0 ml-32 md:ml-60 lg:ml-80 xl:ml-96 para_2 w-full mt-2 mb-2 md:mt-4 md:mb-4'>
        <ul className="flex space-x-5 mt-1 ml-1  md:space-x-20  text-xs md:ml-20 md:text-lg md:my-5 text-white">    
    <li >
          <a href="/">Home</a>
        </li>
        <li>
          <a href="/">Rooms</a>
        </li>
        <li>
          <a href="/">About</a>
        </li>
    </ul>
        </div>
      </div>
      :<NavBar2/>
     }
       <div className='mt-28 ml-12 md:mt-52 md:ml-40 text-white'>
    <h1 className='text-xl md:text-4xl font-semibold'>Welcome to happiness.</h1>
    <div className='mt-2 md:mt-4 md:text-xl'>
    <Typewriter className=''
         onInit={(typewriter)=> {
            typewriter.typeString("Come, stay and enjoy your day.")
            .pauseFor(2000)
            .deleteAll()
            .typeString("We give you a legendary welcome, every time you come back.")
            .start()
         }}
       />
       </div>
    <button type="button" className="bg-blue-600 p-3 rounded-lg font-semibold mt-4">Login / Register</button>
    </div>
    </>
  )
}

export default Navbar1