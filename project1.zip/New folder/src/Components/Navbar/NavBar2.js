import React from 'react'
import logo from "./logo.png"
import "./Navbar2.css"
 
const NavBar2 = () => {
  return (
   <>
    <div className='flex ease-in duration-400'>
        <div className='para1 fixed bg-white w-28 h-12 md:w-1/4 lg:w-72 xl:w-1/4 md:h-16'>
          <div className='md:flex'>
            <div className='mt-3 md:mt-4 lg:ml-8 lg:my-5 w-7 ml-7 lg:mt-7 md:ml-4 lg:ml-1 xl:ml-10'>
            <img src={logo} alt=""/>
            </div>
            <div className='md:static text-xs md:text-lg lg:text-xl font-semibold lg:mt-7 ml-2'>
            <div>tmn's Roommate</div>
            </div>
          </div>
        </div>
        <div className='fixed p-4  md:p-0 ml-24 md:ml-40 lg:ml-64 xl:ml-72 para1_2 w-full h-12 md:h-16 '>
        <ul className="flex space-x-5 mt-1 ml-1  md:space-x-20  text-xs md:ml-20 md:text-lg md:my-5 text-white">    
    <li >
          <a href="/">Home</a>
        </li>
        <li>
          <a href="/">Rooms</a>
        </li>
        <li>
          <a href="/">About</a>
        </li>
    </ul>
        </div>
      </div>
   </>
  )
}

export default NavBar2