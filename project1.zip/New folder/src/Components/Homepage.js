import React, { useState } from 'react'
import Navbar from './Navbar/Navbar1'
import NavBar2 from './Navbar/NavBar2'
import Footer from "./footer1/Footer"

import Card1 from './HotelCard/Card1'

const Homepage = () => {

   

  return (
      
    <>
    
        <Navbar />  
        <Card1/>
        
        <Footer />
        
    </>
  )
}

export default Homepage