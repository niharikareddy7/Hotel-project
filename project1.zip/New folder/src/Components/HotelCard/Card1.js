import React, { useEffect,  useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

import "swiper/css";
import "swiper/css/effect-coverflow";
import "swiper/css/pagination";
import './Services.css'
import {FaCocktail,FaHiking,FaTaxi} from 'react-icons/fa'
import {GiWashingMachine} from 'react-icons/gi'
import {CgGym} from 'react-icons/cg'
import {IoBeerSharp} from 'react-icons/io5'
import { BiBed } from 'react-icons/bi';
import {BsCalendar2Date} from 'react-icons/bs'
import {GoPerson} from 'react-icons/go'


import "./Card1.css";


import { EffectCoverflow, Pagination,Navigation } from "swiper";
 
import 'swiper/css';

const Card1 = () => {
   
  
  const [number,setNumber] = useState(1)
  console.log(number)
  
  useEffect(()=>{
    if(number===0){
      setNumber(1)
    }
    if(number>7){
      setNumber(2)
    }
    if(number<1){
      setNumber(7)
    }
  },[number])
  return (
    <> 
    <div  className="md:ml-16  lg:ml-36">
    <section style={{zIndex:"-1"}} className='mt-28 ser md:mt-20 lg:mt-24 xl:mt-40 mx-5 md:flex ml-40  bg-white w-3/4 justify-between  text-black text-xl border-4 border-yellow-500'>
        
        
        <div className="flex my-4">
        <BiBed style={{marginLeft:"1rem"}} className="mr-2 mt-1 "/>
            <input className=" w-full placeholder:text-sm md:placeholder:text-base" type="text" placeholder="Where are you going?"/>
        </div>
        <div className="flex my-4 ml-4">
        <BsCalendar2Date className=" mr-2 mt-1" />
            <input className=" w-full placeholder:text-sm md:placeholder:text-base" type="text" placeholder="Chich-in - Check-out"/>
        </div>
        <div className="flex my-4 ml-4">
        <GoPerson className="mr-2 mt-1" />
            <input className="w-full placeholder:text-sm md:placeholder:text-base" type="text" placeholder="2 adults : 1 child"/>
        </div>
        <div className="flex w-full md:w-40 md:ml-4">
        <div className="border-t-4 md:border-t-0  md:border-l-4 border-yellow-400" >
        <button  type="button" class="btn  bg-black btn-dark w-56 md:w-36 h-full">Search</button>
                </div>
        </div>
        
    </section>
    </div>
    <div className="s_container">
    <div className='grid grid-cols-1'>
        <div className='  grid justify-center'>
        <h1 className='text-3xl md:text-5xl mt-20 md:mt-12 xl:mt-36 '>Services</h1>
        <div className='border-b-2 w-2/3  border-sky-700'/>
        </div>
        <div  className='ml-4  grid grid-cols-2 md:grid-cols-3 text-xl md:text-3xl mt-10'>
        
            <div className=' hover:text-yellow-300 cursor-pointer'>
                <div className='grid justify-center'>
                <div><FaCocktail/></div>
                </div>
                <h4 className='text-center'>Free Cocktails</h4>
            </div>
            <div className=' hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><FaHiking/></div>
                </div>
                <h4 className='text-center'>Tourist Guide</h4>
            </div>
            <div className='mt-12 md:mt-0 hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><FaTaxi/></div>
                </div>
                <h4 className='text-center'>Cab Service</h4>
            </div>
       
            <div className='mt-12 md:mt-20 hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><GiWashingMachine/></div>
                </div>
                <h4 className='text-center'>Free Laundry</h4>
            </div>
            <div className='mt-12 md:mt-20 hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><CgGym/></div>
                </div>
                <h4 className='text-center'>Gym</h4>
            </div>
            <div className='mt-12 md:mt-20 hover:text-yellow-300 cursor-pointer'>
            <div className='grid justify-center'>
                <div><IoBeerSharp/></div>
                </div>
                <h4 className='text-center'>Strongest Beer</h4>
            </div>
        
        </div>
    
    <div>
    <div className='grid justify-center text-blue-700 mt-40'>
        <h1 className='text-3xl md:text-5xl text_h'>Featured Hotle</h1>
        <div className='border-b-2 w-2/3  border-sky-700'/>
        </div>
    <div className="cont xl:ml-16">
      <Swiper
        effect={"coverflow"}
        
        grabCursor={true}
        centeredSlides={true}
        slidesPerView={"auto"}
        
        onSlideNextTransitionEnd={()=>setNumber(number+1)}
        onSlidePrevTransitionStart={()=>setNumber(number-1)}
        pagination={false}
        
        navigation={true}
        loop={true}
        coverflowEffect={{
          rotate: 45,
          stretch: 0,
          depth: 500,
          modifier: 0.6,
          slideShadows : false,
                  }}
        
        
        modules={[EffectCoverflow, Pagination,Navigation]}
        className="mySwiper "
      >
       <SwiperSlide>
          <img src="https://swiperjs.com/demos/images/nature-5.jpg" alt="" />
          {number===2?<div className="text">
        <h1>Hotle 1</h1>
        <h3> - Kanpur</h3>
        <div className="card_line"/>
        <h6 >Wherever you go, stay with us!</h6>
        </div> : <div></div>}
          
        </SwiperSlide>
        
        <SwiperSlide  >
          <img src="https://swiperjs.com/demos/images/nature-2.jpg" alt='' />
          {number===3?<div className="text">
        <h1>Hotle 2</h1>
        <h3> - Kanpur</h3>
        <div className="card_line"/>
        <h6 >Wherever you go, stay with us!</h6>
        </div> : <div></div>}
        </SwiperSlide>
        <SwiperSlide >
          <img src="https://swiperjs.com/demos/images/nature-3.jpg" alt='' />
          {number===4?<div className="text">
        <h1>Hotle 3</h1>
        <h3> - Kanpur</h3>
        <div className="card_line"/>
        <h6 >Wherever you go, stay with us!</h6>
        </div> : <div></div>}
        </SwiperSlide>
        <SwiperSlide>
          <img src="https://swiperjs.com/demos/images/nature-4.jpg" alt='' />
          {number===5?<div className="text">
        <h1>Hotle 4</h1>
        <h3> - Kanpur</h3>
        <div className="card_line"/>
        <h6 >Wherever you go, stay with us!</h6>
        </div> : <div></div>}
        </SwiperSlide>
        <SwiperSlide  >
          <img src={"https://swiperjs.com/demos/images/nature-1.jpg"} alt=""/>
          {number===6?<div className="text">
        <h1>Hotle 5</h1>
        <h3> - Kanpur</h3>
        <div className="card_line"/>
        <h6 >Wherever you go, stay with us!</h6>
        </div> : <div></div>}
        </SwiperSlide >
        <SwiperSlide>
          <img src="https://swiperjs.com/demos/images/nature-6.jpg" alt=''/>
          {number===7?<div className="text">
        <h1>Hotle 6</h1>
        <h3> - Kanpur</h3>
        <div className="card_line"/>
        <h6 >Wherever you go, stay with us!</h6>
        </div> : <div></div>}
        </SwiperSlide>
        
      </Swiper>
      </div>
      </div>
     </div>
    </div>
   </>
  );
};

export default Card1;
