import Homepage from "./Components/Homepage";



function App() {
  return (
    <>
    <Homepage/>
    </>
  );
}

export default App;
